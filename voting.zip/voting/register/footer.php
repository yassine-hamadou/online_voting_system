
<div class="footer">
	<hr/>
&copy2022. Developed by Fanta Doumbia : ADS20A00042Y.
<br/>
Online Voting System.
<br/>
Final Year Project 2022. Accra Institute Of Technology
<br/>
Contact: <a href="tel:+223-77952155">+233-260861335</a> | Email: <a href="mailto:tdoumbia040@gmail.com">tdoumbia040@gmail.com</a>

</div>
